﻿using System;
using System.Collections.Generic;

namespace TicketingSystem.Models
{
    public partial class Departments
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
